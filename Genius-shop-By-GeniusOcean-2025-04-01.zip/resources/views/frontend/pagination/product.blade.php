 <div class="d-flex justify-content-center align-items-center pt-3" id="custom-pagination">
    <div class="pagination-style-one">
        <nav aria-label="Page navigation example">
            <ul class="pagination">

                {{ $prods->links() }}

            </ul>
        </nav>
    </div>
</div>
