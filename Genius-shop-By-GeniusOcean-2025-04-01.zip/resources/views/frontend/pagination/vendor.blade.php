<div class="d-flex justify-content-between align-items-center pt-3" id="custom-pagination">
    <div class="pagination-style-one">
        <nav aria-label="Page navigation example">
            <ul class="pagination">

                {{ $vprods->links() }}

            </ul>
        </nav>
    </div>
</div>
