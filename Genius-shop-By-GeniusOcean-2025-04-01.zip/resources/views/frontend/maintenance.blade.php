{!! clean($gs->maintain_text , array('Attr.EnableID' => true)) !!}
